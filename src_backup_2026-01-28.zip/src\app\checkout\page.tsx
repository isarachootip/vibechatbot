"use client";

import { useState } from "react";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { ArrowLeft, CreditCard, Truck, Banknote } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";

import { createOrder } from "@/actions/order";

export default function CheckoutPage() {
    const { items, cartTotal, clearCart } = useCart();
    const router = useRouter();
    const [isProcessing, setIsProcessing] = useState(false);
    const [error, setError] = useState<string | null>(null);

    // Mock Shipping Cost
    const shippingCost = cartTotal > 1000 ? 0 : 50;
    const total = cartTotal + shippingCost;

    const handlePlaceOrder = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setIsProcessing(true);
        setError(null);

        const formData = new FormData(e.currentTarget);
        const shipping = {
            name: formData.get("name") as string,
            email: formData.get("email") as string,
            address: formData.get("address") as string,
            city: formData.get("city") as string,
            zip: formData.get("zip") as string,
            phone: formData.get("phone") as string,
        };

        const cartItemsInput = items.map(item => ({
            id: item.id,
            quantity: item.quantity,
            selectedVariant: item.selectedVariant
        }));

        const result = await createOrder(cartItemsInput, shipping);

        if (result.error) {
            setError(result.error);
            setIsProcessing(false);
        } else {
            clearCart();
            setIsProcessing(false);
            router.push("/checkout/success");
        }
    };

    if (items.length === 0) {
        return (
            <div className="container mx-auto flex min-h-[60vh] flex-col items-center justify-center px-4">
                <h1 className="text-2xl font-bold">Your cart is empty</h1>
                <p className="mt-2 text-muted-foreground">Add some items to get started.</p>
                <Link href="/">
                    <Button className="mt-6">
                        Back to Shop
                    </Button>
                </Link>
            </div>
        );
    }

    return (
        <div className="container mx-auto px-4 py-8 lg:py-12">
            <div className="mb-8">
                <Link href="/" className="inline-flex items-center text-sm text-muted-foreground hover:text-primary">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Continue Shopping
                </Link>
                <h1 className="mt-4 text-3xl font-bold tracking-tight">Checkout</h1>
            </div>

            <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
                {/* Left Column: Shipping Form */}
                <div className="lg:col-span-7">
                    <form id="checkout-form" onSubmit={handlePlaceOrder} className="space-y-8">
                        {/* Contact Info */}
                        <section>
                            <h2 className="text-xl font-semibold mb-4">Contact Information</h2>
                            <div className="grid grid-cols-1 gap-4">
                                <div className="space-y-2">
                                    <label htmlFor="email" className="text-sm font-medium">Email Address</label>
                                    <input
                                        required
                                        type="email"
                                        id="email"
                                        placeholder="john@example.com"
                                        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                    />
                                </div>
                            </div>
                        </section>

                        {/* Shipping Address */}
                        <section>
                            <h2 className="text-xl font-semibold mb-4">Shipping Address</h2>
                            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                <div className="space-y-2 sm:col-span-2">
                                    <label htmlFor="name" className="text-sm font-medium">Full Name</label>
                                    <input
                                        required
                                        type="text"
                                        id="name"
                                        placeholder="John Doe"
                                        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                    />
                                </div>
                                <div className="space-y-2 sm:col-span-2">
                                    <label htmlFor="address" className="text-sm font-medium">Address</label>
                                    <input
                                        required
                                        type="text"
                                        id="address"
                                        placeholder="123 Main St"
                                        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label htmlFor="city" className="text-sm font-medium">City</label>
                                    <input
                                        required
                                        type="text"
                                        id="city"
                                        placeholder="Bangkok"
                                        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label htmlFor="zip" className="text-sm font-medium">Zip Code</label>
                                    <input
                                        required
                                        type="text"
                                        id="zip"
                                        placeholder="10110"
                                        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                    />
                                </div>
                                <div className="space-y-2 sm:col-span-2">
                                    <label htmlFor="phone" className="text-sm font-medium">Phone Number</label>
                                    <input
                                        required
                                        type="tel"
                                        id="phone"
                                        placeholder="081-234-5678"
                                        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                    />
                                </div>
                            </div>
                        </section>

                        {/* Payment Method */}
                        <section>
                            <h2 className="text-xl font-semibold mb-4">Payment Method</h2>
                            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                                <label className="cursor-pointer rounded-lg border bg-card p-4 hover:border-primary peer-checked:border-primary has-[:checked]:border-primary has-[:checked]:bg-primary/5">
                                    <input type="radio" name="payment" className="sr-only" defaultChecked />
                                    <div className="flex flex-col items-center gap-2 text-center">
                                        <CreditCard className="h-6 w-6" />
                                        <span className="text-sm font-medium">Credit Card</span>
                                    </div>
                                </label>
                                <label className="cursor-pointer rounded-lg border bg-card p-4 hover:border-primary peer-checked:border-primary has-[:checked]:border-primary has-[:checked]:bg-primary/5">
                                    <input type="radio" name="payment" className="sr-only" />
                                    <div className="flex flex-col items-center gap-2 text-center">
                                        <Banknote className="h-6 w-6" />
                                        <span className="text-sm font-medium">Bank Transfer</span>
                                    </div>
                                </label>
                                <label className="cursor-pointer rounded-lg border bg-card p-4 hover:border-primary peer-checked:border-primary has-[:checked]:border-primary has-[:checked]:bg-primary/5">
                                    <input type="radio" name="payment" className="sr-only" />
                                    <div className="flex flex-col items-center gap-2 text-center">
                                        <Truck className="h-6 w-6" />
                                        <span className="text-sm font-medium">Cash on Delivery</span>
                                    </div>
                                </label>
                            </div>
                        </section>
                    </form>
                </div>

                {/* Right Column: Order Summary */}
                <div className="lg:col-span-5">
                    <div className="sticky top-24 rounded-lg border bg-gray-50/50 p-6 shadow-sm">
                        <h2 className="text-lg font-semibold mb-4">Order Summary</h2>

                        {/* Items */}
                        <ul className="mb-6 space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                            {items.map((item) => (
                                <li key={`${item.id}-${item.selectedVariant?.color}-${item.selectedVariant?.size}`} className="flex gap-4">
                                    <div className="relative h-16 w-16 flex-none overflow-hidden rounded-md border bg-white">
                                        <Image
                                            src={item.images[0]}
                                            alt={item.name}
                                            fill
                                            className="object-cover"
                                        />
                                    </div>
                                    <div className="flex flex-1 flex-col justify-center">
                                        <h3 className="text-sm font-medium line-clamp-1">{item.name}</h3>
                                        <p className="text-xs text-muted-foreground">
                                            {item.selectedVariant?.color && `${item.selectedVariant.color}, `}
                                            {item.selectedVariant?.size && item.selectedVariant.size}
                                        </p>
                                        <div className="mt-1 flex justify-between text-sm">
                                            <span className="text-muted-foreground">Qty {item.quantity}</span>
                                            <span className="font-medium">฿{((item.salePrice || item.price) * item.quantity).toLocaleString()}</span>
                                        </div>
                                    </div>
                                </li>
                            ))}
                        </ul>

                        <div className="h-px bg-border mb-6" />

                        {/* Costs */}
                        <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Subtotal</span>
                                <span>฿{cartTotal.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-muted-foreground">Shipping</span>
                                <span>{shippingCost === 0 ? "Free" : `฿${shippingCost.toLocaleString()}`}</span>
                            </div>
                        </div>

                        <div className="h-px bg-border my-4" />

                        <div className="flex justify-between text-lg font-bold">
                            <span>Total</span>
                            <span>฿{total.toLocaleString()}</span>
                        </div>

                        <Button
                            type="submit"
                            form="checkout-form"
                            className="w-full mt-6 text-lg h-12"
                            size="lg"
                            disabled={isProcessing}
                        >
                            {isProcessing ? "Processing..." : "Place Order"}
                        </Button>

                        <p className="mt-4 text-center text-xs text-muted-foreground">
                            Secure checkout powered by Stripe (Mock)
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
}
