"use server";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { OrderStatus } from "@prisma/client";
import { revalidatePath } from "next/cache";

export async function updateOrderStatus(orderId: string, newStatus: OrderStatus) {
    try {
        const session = await auth();

        // Strict Admin Check
        if (session?.user?.role !== "ADMIN") {
            return { error: "Unauthorized" };
        }

        await prisma.order.update({
            where: { id: orderId },
            data: { status: newStatus },
        });

        revalidatePath(`/admin/orders/${orderId}`);
        revalidatePath("/admin/orders");

        return { success: true };
    } catch (error) {
        console.error("Failed to update status:", error);
        return { error: "Failed to update status" };
    }
}
