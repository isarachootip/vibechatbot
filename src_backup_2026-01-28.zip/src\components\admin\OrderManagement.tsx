"use client";

import { useState } from "react";
import { Order, User, OrderItem, Product } from "@prisma/client";
import { OrderStatusSelector } from "./OrderStatusSelector";
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, ArrowUpDown } from "lucide-react";

type ExtendedOrder = Order & {
    User: User | null;
    items: (OrderItem & { Product: Product })[];
};

interface Props {
    initialOrders: ExtendedOrder[];
}

const ITEMS_PER_PAGE = 30;

export function OrderManagement({ initialOrders }: Props) {
    const [filterStatus, setFilterStatus] = useState<string>("ALL");
    const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
    const [currentPage, setCurrentPage] = useState(1);
    const [sortField, setSortField] = useState<"queueNumber" | "customerName" | "deliveryLocation" | "createdAt">("createdAt");
    const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");

    // Calculate date range (15 days back from selected date)
    const fifteenDaysAgo = new Date(selectedDate);
    fifteenDaysAgo.setDate(fifteenDaysAgo.getDate() - 15);

    // Filter Logic
    const filteredOrders = initialOrders.filter(order => {
        // Status Filter
        if (filterStatus !== "ALL" && order.status !== filterStatus) return false;

        // Date Range Filter (last 15 days from selected date)
        const orderDate = new Date(order.createdAt);
        const selected = new Date(selectedDate);
        selected.setHours(23, 59, 59, 999); // Set to end of day

        if (orderDate > selected || orderDate < fifteenDaysAgo) return false;

        return true;
    });

    // Sort Logic
    const sortedOrders = [...filteredOrders].sort((a, b) => {
        let comparison = 0;

        switch (sortField) {
            case "queueNumber":
                const qA = a.queueNumber || 0;
                const qB = b.queueNumber || 0;
                comparison = qA - qB;
                break;
            case "customerName":
                const nameA = a.customerName || a.User?.name || "";
                const nameB = b.customerName || b.User?.name || "";
                comparison = nameA.localeCompare(nameB);
                break;
            case "deliveryLocation":
                const locA = a.deliveryLocation || "";
                const locB = b.deliveryLocation || "";
                comparison = locA.localeCompare(locB);
                break;
            case "createdAt":
                comparison = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
                break;
        }

        return sortOrder === "asc" ? comparison : -comparison;
    });

    // Pagination
    const totalPages = Math.ceil(sortedOrders.length / ITEMS_PER_PAGE);
    const startIdx = (currentPage - 1) * ITEMS_PER_PAGE;
    const paginatedOrders = sortedOrders.slice(startIdx, startIdx + ITEMS_PER_PAGE);

    const handleSort = (field: typeof sortField) => {
        if (sortField === field) {
            setSortOrder(sortOrder === "asc" ? "desc" : "asc");
        } else {
            setSortField(field);
            setSortOrder("asc");
        }
    };

    const formatDateTime = (date: Date | string) => {
        return new Date(date).toLocaleString('th-TH', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const getDeliveryBadge = (type: string | null, location: string | null) => {
        if (!type) return null;

        if (type === 'PICKUP') {
            return (
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-green-100 text-green-700">
                    รับเอง
                </span>
            );
        }

        return (
            <div className="flex flex-col gap-0.5">
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-100 text-blue-700">
                    จัดส่ง
                </span>
                {location && (
                    <span className="text-[9px] text-gray-500">📍 {location}</span>
                )}
            </div>
        );
    };

    // Dates for dropdown (last 15 days)
    const dateOptions = [];
    for (let i = 0; i <= 15; i++) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        dateOptions.push(date.toISOString().split('T')[0]);
    }

    return (
        <div className="space-y-6 bg-yellow-50 min-h-screen p-6">

            {/* Header / Filters */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    {/* Date Picker */}
                    <div className="flex items-center gap-2 border rounded-md px-3 py-2 bg-white w-fit">
                        <CalendarIcon size={16} className="text-gray-500" />
                        <select
                            className="text-sm text-gray-700 outline-none cursor-pointer bg-transparent"
                            value={selectedDate}
                            onChange={(e) => {
                                setSelectedDate(e.target.value);
                                setCurrentPage(1);
                            }}
                        >
                            {dateOptions.map(date => (
                                <option key={date} value={date}>
                                    {new Date(date).toLocaleDateString('th-TH', {
                                        day: '2-digit',
                                        month: 'short',
                                        year: 'numeric'
                                    })}
                                </option>
                            ))}
                        </select>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Showing: Last 15 days from selected date</p>
                </div>

                <div className="flex items-center gap-2">
                    <select
                        className="h-10 pl-3 pr-8 rounded-md border text-sm focus:ring-2 focus:ring-yellow-400/50 outline-none cursor-pointer bg-white"
                        value={filterStatus}
                        onChange={(e) => {
                            setFilterStatus(e.target.value);
                            setCurrentPage(1);
                        }}
                    >
                        <option value="ALL">Status: All</option>
                        <option value="PENDING">รอรับ</option>
                        <option value="PAID">รับออเดอร์</option>
                        <option value="PROCESSING">กำลังทำ</option>
                        <option value="SHIPPED">เสร็จแล้ว</option>
                        <option value="COMPLETED">จบงาน</option>
                        <option value="CANCELLED">ยกเลิก</option>
                    </select>
                    <span className="text-xs text-gray-600">
                        Total: {sortedOrders.length} orders
                    </span>
                </div>
            </div>

            {/* Table */}
            <div className="rounded-lg border bg-white shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="bg-yellow-50/80 border-b border-yellow-100 text-gray-600 font-medium uppercase text-xs tracking-wider">
                            <tr>
                                <th
                                    className="px-4 py-3 cursor-pointer hover:bg-yellow-100 select-none"
                                    onClick={() => handleSort("queueNumber")}
                                >
                                    <div className="flex items-center gap-1">
                                        Queue
                                        <ArrowUpDown className="h-3 w-3" />
                                    </div>
                                </th>
                                <th
                                    className="px-4 py-3 cursor-pointer hover:bg-yellow-100 select-none"
                                    onClick={() => handleSort("createdAt")}
                                >
                                    <div className="flex items-center gap-1">
                                        Date/Time
                                        <ArrowUpDown className="h-3 w-3" />
                                    </div>
                                </th>
                                <th className="px-4 py-3">Order ID</th>
                                <th
                                    className="px-4 py-3 cursor-pointer hover:bg-yellow-100 select-none"
                                    onClick={() => handleSort("customerName")}
                                >
                                    <div className="flex items-center gap-1">
                                        Customer
                                        <ArrowUpDown className="h-3 w-3" />
                                    </div>
                                </th>
                                <th className="px-4 py-3">Items</th>
                                <th
                                    className="px-4 py-3 cursor-pointer hover:bg-yellow-100 select-none"
                                    onClick={() => handleSort("deliveryLocation")}
                                >
                                    <div className="flex items-center gap-1">
                                        Type / Location
                                        <ArrowUpDown className="h-3 w-3" />
                                    </div>
                                </th>
                                <th className="px-4 py-3">Total</th>
                                <th className="px-4 py-3">Slip</th>
                                <th className="px-4 py-3">Status</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {paginatedOrders.length === 0 ? (
                                <tr>
                                    <td colSpan={8} className="px-6 py-12 text-center text-gray-400">
                                        No orders found.
                                    </td>
                                </tr>
                            ) : (
                                paginatedOrders.map((order) => (
                                    <tr key={order.id} className="hover:bg-yellow-50/30 transition-colors">
                                        {/* QUEUE NUMBER */}
                                        <td className="px-4 py-3">
                                            {order.queueNumber ? (
                                                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-yellow-400 text-gray-900 font-bold text-sm">
                                                    {order.queueNumber}
                                                </div>
                                            ) : (
                                                <span className="text-gray-300 text-xs">-</span>
                                            )}
                                        </td>

                                        {/* DATE/TIME */}
                                        <td className="px-4 py-3 text-gray-600 text-xs whitespace-nowrap">
                                            {formatDateTime(order.createdAt)}
                                        </td>

                                        {/* ORDER ID */}
                                        <td className="px-4 py-3 font-mono text-gray-700 text-xs">
                                            #{order.id.slice(-6).toUpperCase()}
                                        </td>

                                        {/* CUSTOMER */}
                                        <td className="px-4 py-3">
                                            <div className="flex flex-col gap-0.5">
                                                <span className="font-semibold text-gray-900 text-sm">
                                                    {order.customerName || order.User?.name || "Guest"}
                                                </span>
                                                {order.customerPhone && (
                                                    <span className="text-[10px] text-gray-500">📞 {order.customerPhone}</span>
                                                )}
                                                {order.lineUserId && (
                                                    <span className="text-[9px] text-blue-500">LINE Order</span>
                                                )}
                                            </div>
                                        </td>

                                        {/* ITEMS */}
                                        <td className="px-4 py-3">
                                            <div className="flex flex-col gap-0.5 max-w-[200px]">
                                                {order.items.slice(0, 2).map((item, idx) => (
                                                    <div key={idx} className="text-gray-700 text-xs flex items-center gap-1">
                                                        <span className="w-1 h-1 rounded-full bg-gray-400"></span>
                                                        <span className="truncate">{item.Product.name}</span>
                                                        <span className="text-gray-400">x{item.quantity}</span>
                                                    </div>
                                                ))}
                                                {order.items.length > 2 && (
                                                    <span className="text-[10px] text-gray-400">+{order.items.length - 2} more</span>
                                                )}
                                            </div>
                                        </td>

                                        {/* DELIVERY TYPE / LOCATION */}
                                        <td className="px-4 py-3">
                                            {getDeliveryBadge(order.deliveryType, order.deliveryLocation)}
                                        </td>

                                        {/* TOTAL */}
                                        <td className="px-4 py-3 font-bold text-gray-900 whitespace-nowrap">
                                            ฿{Number(order.total).toLocaleString()}
                                        </td>

                                        {/* SLIP */}
                                        <td className="px-4 py-3">
                                            {order.paymentSlipUrl ? (
                                                <a
                                                    href={order.paymentSlipUrl}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    className="text-blue-500 hover:text-blue-700 underline text-xs flex items-center gap-1"
                                                >
                                                    View Slip
                                                </a>
                                            ) : (
                                                <span className="text-gray-300 text-xs">-</span>
                                            )}
                                        </td>

                                        {/* STATUS */}
                                        <td className="px-4 py-3">
                                            <OrderStatusSelector orderId={order.id} currentStatus={order.status} />
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                    <div className="flex items-center justify-between border-t border-gray-200 bg-white px-4 py-3">
                        <div className="flex items-center gap-2">
                            <button
                                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                                disabled={currentPage === 1}
                                className="px-3 py-1.5 rounded border text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
                            >
                                <ChevronLeft size={16} />
                            </button>
                            <span className="text-sm text-gray-700">
                                Page {currentPage} of {totalPages}
                            </span>
                            <button
                                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                                disabled={currentPage === totalPages}
                                className="px-3 py-1.5 rounded border text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
                            >
                                <ChevronRight size={16} />
                            </button>
                        </div>
                        <div className="text-xs text-gray-500">
                            Showing {startIdx + 1}-{Math.min(startIdx + ITEMS_PER_PAGE, sortedOrders.length)} of {sortedOrders.length}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
