"use client";

import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Product } from "@/types";

export interface CartItem extends Product {
    quantity: number;
    selectedVariant?: {
        color?: string;
        size?: string;
    };
}

interface CartContextType {
    items: CartItem[];
    addItem: (product: Product, quantity?: number, variant?: CartItem["selectedVariant"]) => void;
    removeItem: (productId: string) => void;
    updateQuantity: (productId: string, quantity: number) => void;
    clearCart: () => void;
    toggleCart: () => void;
    isCartOpen: boolean;
    cartCount: number;
    cartTotal: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
    const [items, setItems] = useState<CartItem[]>([]);
    const [isCartOpen, setIsCartOpen] = useState(false);
    const [isMounted, setIsMounted] = useState(false);

    // Load from LocalStorage on mount
    useEffect(() => {
        // eslint-disable-next-line
        setIsMounted(true);
        const savedCart = localStorage.getItem("cart");
        if (savedCart) {
            try {
                const parsed = JSON.parse(savedCart);
                if (Array.isArray(parsed)) {
                    setItems(parsed);
                } else {
                    console.error("Cart data is not an array", parsed);
                    setItems([]); // Reset if invalid
                }
            } catch (e) {
                console.error("Failed to parse cart", e);
                setItems([]);
            }
        }
    }, []);

    // Save to LocalStorage on change
    useEffect(() => {
        if (isMounted) {
            localStorage.setItem("cart", JSON.stringify(items));
        }
    }, [items, isMounted]);

    const addItem = (product: Product, quantity = 1, variant?: CartItem["selectedVariant"]) => {
        setItems((currentItems) => {
            const existingItem = currentItems.find((item) => item.id === product.id);

            // Simple logic: If same product (ignoring variant for now for simplicity, or we can add strict variant check)
            if (existingItem) {
                return currentItems.map((item) =>
                    item.id === product.id
                        ? { ...item, quantity: item.quantity + quantity }
                        : item
                );
            }

            return [...currentItems, { ...product, quantity, selectedVariant: variant }];
        });
        setIsCartOpen(true); // Open cart when adding
    };

    const removeItem = (productId: string) => {
        setItems((currentItems) => currentItems.filter((item) => item.id !== productId));
    };

    const updateQuantity = (productId: string, quantity: number) => {
        if (quantity < 1) {
            removeItem(productId);
            return;
        }
        setItems((currentItems) =>
            currentItems.map((item) =>
                item.id === productId ? { ...item, quantity } : item
            )
        );
    };

    const clearCart = () => setItems([]);

    const toggleCart = () => setIsCartOpen((prev) => !prev);

    const cartCount = items.reduce((total, item) => total + item.quantity, 0);

    const cartTotal = items.reduce((total, item) => {
        const price = item.salePrice || item.price;
        return total + (price * item.quantity);
    }, 0);

    return (
        <CartContext.Provider
            value={{
                items,
                addItem,
                removeItem,
                updateQuantity,
                clearCart,
                toggleCart,
                isCartOpen,
                cartCount,
                cartTotal,
            }}
        >
            {children}
        </CartContext.Provider>
    );
}

export function useCart() {
    const context = useContext(CartContext);
    if (context === undefined) {
        throw new Error("useCart must be used within a CartProvider");
    }
    return context;
}
