import { Loader2 } from "lucide-react";

export default function AdminLoading() {
    return (
        <div className="flex h-[50vh] w-full items-center justify-center">
            <div className="flex flex-col items-center gap-2">
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
                <p className="text-sm text-muted-foreground">Loading Admin Console...</p>
            </div>
        </div>
    );
}
