"use server";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";

interface CartItemInput {
    id: string; // Product ID
    quantity: number;
    selectedVariant?: {
        color?: string;
        size?: string;
    };
}

interface ShippingInput {
    name: string;
    email: string;
    address: string;
    city: string;
    zip: string;
    phone: string;
}

export async function createOrder(items: CartItemInput[], shipping: ShippingInput) {
    try {
        const session = await auth();
        const userId = session?.user?.id;

        if (items.length === 0) {
            return { error: "Cart is empty" };
        }

        // 1. Fetch products to get real prices
        const productIds = items.map((item) => item.id);
        const dbProducts = await prisma.product.findMany({
            where: { id: { in: productIds } },
        });

        const productsMap = new Map(dbProducts.map((p) => [p.id, p]));

        // 2. Calculate Total & Prepare OrderItems
        let total = 0;
        const orderItemsData = [];

        for (const item of items) {
            const product = productsMap.get(item.id);
            if (!product) {
                return { error: `Product not found: ${item.id}` };
            }

            // Use Sale Price if available, otherwise Normal Price
            // Note: Decimal type in Prisma needs handling, but for now assuming standard JS number compatibility or conversion
            // In a real app we should use Decimal.js for money math. Here strictly standard number for MVP.
            const price = product.promotionPrice ? Number(product.promotionPrice) : Number(product.price);

            total += price * item.quantity;

            orderItemsData.push({
                productId: product.id,
                quantity: item.quantity,
                price: price, // Store snapshot of price
            });
        }

        // Add Shipping Cost (Logic matches frontend: > 1000 free, else 50)
        const shippingCost = total > 1000 ? 0 : 50;
        total += shippingCost;

        // 3. Create Order
        const order = await prisma.order.create({
            data: {
                userId: userId || null, // Can be null for guest (though our schema allows it? Yes userId String?)
                status: "PENDING",
                total: total,
                shippingAddress: JSON.stringify(shipping), // Simple JSON storage for address
                items: {
                    create: orderItemsData,
                },
            },
        });

        revalidatePath("/admin/orders"); // Revalidate admin panel if exists

        return { success: true, orderId: order.id };

    } catch (error) {
        console.error("Failed to create order:", error);
        return { error: "Failed to create order. Please try again." };
    }
}
