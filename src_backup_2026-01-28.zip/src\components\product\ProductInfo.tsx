"use client";

import { useState } from "react";
import { Heart, Minus, Plus, ShoppingCart, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Product } from "@/types";
import { cn } from "@/lib/utils";

import { useCart } from "@/context/CartContext";

interface ProductInfoProps {
    product: Product;
}

export function ProductInfo({ product }: ProductInfoProps) {
    const { addItem } = useCart();
    const [quantity, setQuantity] = useState(1);
    const [selectedColor, setSelectedColor] = useState<string | null>(null);
    const [selectedSize, setSelectedSize] = useState<string | null>(null);

    // Mock Variants (In real app, this comes from DB)
    const COLORS = [
        { name: "Black", value: "#000000" },
        { name: "White", value: "#ffffff" },
        { name: "Navy", value: "#1a237e" },
    ];
    const SIZES = ["S", "M", "L", "XL"];

    const decreaseQty = () => setQuantity((prev) => Math.max(1, prev - 1));
    const increaseQty = () => setQuantity((prev) => prev + 1);

    const handleAddToCart = () => {
        addItem(product, quantity, {
            color: selectedColor || undefined,
            size: selectedSize || undefined
        });
    };

    return (
        <div className="flex flex-col gap-6">
            {/* Header */}
            <div>
                <h1 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
                    {product.name}
                </h1>
                <div className="mt-2 flex items-center gap-4">
                    <div className="flex items-center gap-2">
                        {product.salePrice ? (
                            <>
                                <span className="text-3xl font-bold text-red-600">
                                    ฿{product.salePrice.toLocaleString()}
                                </span>
                                <span className="text-xl text-muted-foreground line-through">
                                    ฿{product.price.toLocaleString()}
                                </span>
                                <span className="rounded-md bg-red-100 px-2 py-1 text-sm font-semibold text-red-700">
                                    Save {Math.round(((product.price - product.salePrice) / product.price) * 100)}%
                                </span>
                            </>
                        ) : (
                            <span className="text-3xl font-bold text-gray-900">
                                ฿{product.price.toLocaleString()}
                            </span>
                        )}
                    </div>
                </div>
            </div>

            <div className="h-px bg-border" />

            {/* Description */}
            <div className="text-base text-muted-foreground">
                <p>{product.description || "สัมผัสประสบการณ์สินค้าคุณภาพระดับพรีเมียม ออกแบบมาอย่างพิถีพิถันเพื่อตอบโจทย์ไลฟ์สไตล์ของคุณ วัสดุเกรด A ทนทานและสวยงาม"}</p>
            </div>

            {/* Selectors */}
            <div className="space-y-4">
                {/* Color Selector */}
                <div>
                    <h3 className="mb-3 text-sm font-medium text-gray-900">Color</h3>
                    <div className="flex items-center gap-3">
                        {COLORS.map((color) => (
                            <button
                                key={color.name}
                                onClick={() => setSelectedColor(color.name)}
                                className={cn(
                                    "relative h-8 w-8 rounded-full ring-offset-2 focus:outline-none focus:ring-2 focus:ring-primary",
                                    selectedColor === color.name ? "ring-2 ring-primary" : "border border-gray-200"
                                )}
                                title={color.name}
                            >
                                <span
                                    className="absolute inset-0 rounded-full border border-black/10"
                                    style={{ backgroundColor: color.value }}
                                />
                            </button>
                        ))}
                    </div>
                </div>

                {/* Size Selector */}
                <div>
                    <h3 className="mb-3 text-sm font-medium text-gray-900">Size</h3>
                    <div className="flex items-center gap-3">
                        {SIZES.map((size) => (
                            <button
                                key={size}
                                onClick={() => setSelectedSize(size)}
                                className={cn(
                                    "flex h-10 min-w-[3rem] items-center justify-center rounded-md border text-sm font-medium transition-all hover:border-primary hover:text-primary",
                                    selectedSize === size
                                        ? "border-primary bg-primary/5 text-primary"
                                        : "border-input bg-background"
                                )}
                            >
                                {size}
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col gap-4 sm:flex-row sm:items-end">
                {/* Quantity */}
                <div className="space-y-2">
                    <span className="text-sm font-medium">Quantity</span>
                    <div className="flex items-center rounded-md border">
                        <Button
                            variant="ghost"
                            size="icon"
                            className="h-10 w-10 rounded-none"
                            onClick={decreaseQty}
                            disabled={quantity <= 1}
                        >
                            <Minus className="h-4 w-4" />
                        </Button>
                        <div className="flex h-10 w-12 items-center justify-center border-x text-center text-sm">
                            {quantity}
                        </div>
                        <Button
                            variant="ghost"
                            size="icon"
                            className="h-10 w-10 rounded-none"
                            onClick={increaseQty}
                        >
                            <Plus className="h-4 w-4" />
                        </Button>
                    </div>
                </div>

                {/* Add to Cart */}
                <Button
                    className="h-12 flex-1 gap-2 text-base"
                    size="lg"
                    onClick={handleAddToCart}
                >
                    <ShoppingCart className="h-5 w-5" />
                    Add to Cart
                </Button>

                {/* Wishlist */}
                <Button variant="outline" size="icon" className="h-12 w-12">
                    <Heart className="h-5 w-5" />
                </Button>
            </div>

            {/* Additional Info */}
            <div className="mt-4 flex gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-green-500" />
                    In Stock (Ready to ship)
                </div>
            </div>
        </div>
    );
}
