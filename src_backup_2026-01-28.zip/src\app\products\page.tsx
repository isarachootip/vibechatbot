import { FilterSidebar } from "@/components/product/FilterSidebar";
import { ProductCard } from "@/components/product/ProductCard";
import { Product } from "@/types";
import { Button } from "@/components/ui/button";
import { SlidersHorizontal } from "lucide-react";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

async function getProducts(searchParams: { category?: string; min?: string; max?: string; q?: string }) {
    // Basic filtering logic
    const where: any = {};
    if (searchParams.category) where.category = { slug: searchParams.category };
    if (searchParams.min) where.price = { gte: Number(searchParams.min) };
    if (searchParams.max) where.price = { lte: Number(searchParams.max) };
    if (searchParams.q) {
        where.OR = [
            { name: { contains: searchParams.q, mode: 'insensitive' } },
            { nameTh: { contains: searchParams.q, mode: 'insensitive' } }
        ];
    }

    const products = await prisma.product.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        include: { Category: true }
    });

    // Map Prisma result to Frontend Product Interface
    return products.map(p => ({
        id: p.id,
        name: p.name,
        nameTh: p.name, // Schema removed nameTh, use name as fallback
        description: p.description || "",
        price: Number(p.price) || 0,
        salePrice: undefined,
        images: p.images.length > 0 ? p.images : ['/placeholder.jpg'],
        category: p.Category?.name || "Uncategorized",
        inStock: p.inventory > 0,
        isNew: (new Date().getTime() - new Date(p.createdAt).getTime()) < (7 * 24 * 60 * 60 * 1000)
    })) as Product[];
}

export default async function ProductsPage({ searchParams }: { searchParams: { category?: string; min?: string; max?: string; q?: string } }) {
    const products = await getProducts(searchParams);
    // Map categories to have a slug (using name)
    const rawCategories = await prisma.category.findMany({ orderBy: { name: 'asc' } });
    const categories = rawCategories.map(c => ({ ...c, slug: c.name }));

    return (
        <div className="container mx-auto px-4 py-8">
            {/* Page Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">สินค้าทั้งหมด</h1>
                    <p className="text-muted-foreground mt-1">แสดง {products.length} รายการ</p>
                </div>

                {/* Mobile Filter Toggle (Visible only on mobile) */}
                <Button variant="outline" className="lg:hidden w-full gap-2">
                    <SlidersHorizontal className="h-4 w-4" /> ตัวกรอง
                </Button>
            </div>

            <div className="flex flex-col lg:flex-row gap-8">
                {/* Sidebar (Desktop) */}
                <aside className="w-full lg:w-64 flex-none">
                    <FilterSidebar categories={categories} />
                </aside>

                {/* Product Grid */}
                <div className="flex-1">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        {products.map((product) => (
                            <ProductCard key={product.id} product={product} />
                        ))}
                    </div>
                    {products.length === 0 && (
                        <div className="py-24 text-center">
                            <h3 className="text-lg font-medium">ไม่พบสินค้า</h3>
                            <p className="text-muted-foreground">ลองปรับตัวกรองดูนะครับ</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
