import { getBankConfigs } from "@/actions/bank-config";
import BankConfigClient from "@/components/admin/BankConfigClient";

export const dynamic = "force-dynamic";

export default async function BankConfigPage() {
    const banks = await getBankConfigs();

    return (
        <div>
            <div className="mb-6">
                <h1 className="text-2xl font-bold tracking-tight text-gray-900">Payment Settings</h1>
                <p className="text-sm text-gray-500">Configure receiving accounts for QR Code generation</p>
            </div>

            <BankConfigClient initialBanks={banks} />
        </div>
    );
}
